/* عامل خدمة نظام سجل المذكرين والمتذاكرين — يتيح فتح التطبيق بدون إنترنت ويحدّث نفسه تلقائياً */
const CACHE_NAME = 'thikr-cache-v1';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

/* استقبال إشعار فوري (Push) وعرضه في لوحة إشعارات الجهاز + شارة على الأيقونة */
self.addEventListener('push', (event) => {
  let payload = { title: 'سجل المذكرين والمتذاكرين', body: 'لديك تنبيه جديد' };
  try { payload = event.data.json(); } catch(e) { /* نص عادي بدون JSON */ }
  event.waitUntil(
    self.registration.showNotification(payload.title || 'تنبيه جديد', {
      body: payload.body || '',
      icon: './icon-192.png',
      badge: './icon-192.png',
      dir: 'rtl',
      lang: 'ar'
    })
  );
  if (self.registration.setAppBadge) {
    event.waitUntil(self.registration.setAppBadge(1).catch(()=>{}));
  } else if (self.setAppBadge) {
    event.waitUntil(self.setAppBadge(1).catch(()=>{}));
  }
});

/* عند الضغط على الإشعار: فتح التطبيق ومسح الشارة */
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  if (self.registration.clearAppBadge) self.registration.clearAppBadge().catch(()=>{});
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsArr) => {
      const existing = clientsArr.find((c) => c.url.includes(self.registration.scope));
      if (existing) return existing.focus();
      return clients.openWindow('./index.html');
    })
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;

  // لا نتدخل أبداً في طلبات Supabase (بيانات حية) — تذهب مباشرة للشبكة دائماً
  if (req.url.includes('supabase.co')) return;

  // صفحة التطبيق نفسها: الشبكة أولاً مع رجوع للنسخة المخزنة عند انقطاع الإنترنت
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const clone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put('./index.html', clone));
          return res;
        })
        .catch(() => caches.match('./index.html'))
    );
    return;
  }

  // بقية الملفات (خطوط، مكتبات، أيقونات): من الذاكرة المؤقتة أولاً مع تحديث بالخلفية
  event.respondWith(
    caches.match(req).then((cached) => {
      const fetchPromise = fetch(req)
        .then((res) => {
          if (res && res.status === 200) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
          }
          return res;
        })
        .catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
